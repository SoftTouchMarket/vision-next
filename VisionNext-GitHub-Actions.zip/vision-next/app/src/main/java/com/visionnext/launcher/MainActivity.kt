package com.visionnext.launcher

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** Vision Next alpha: TV-friendly launcher prototype. Not a replacement for system firmware. */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private val accent = Color.rgb(154, 140, 255)
    private val bg = Color.rgb(9, 11, 18)
    private val panel = Color.rgb(24, 28, 42)
    private val speechRequest = 4102
    private val permissionRequest = 4103

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        buildHome()
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(48), dp(28), dp(48), dp(28))
            setBackgroundColor(bg)
            isFocusableInTouchMode = true
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            text = "VISION  NEXT"
            textSize = 25f; setTextColor(Color.WHITE); letterSpacing = .12f
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply {
            text = "HOME  •  SMART TV"
            textSize = 13f; setTextColor(Color.LTGRAY)
        })
        root.addView(top)
        root.addView(TextView(this).apply {
            text = "Всё нужное — на одном экране"
            textSize = 31f; setTextColor(Color.WHITE); setPadding(0, dp(24), 0, dp(8))
        })
        root.addView(TextView(this).apply {
            text = "Лёгкая оболочка для Huawei Vision S55"
            textSize = 16f; setTextColor(Color.rgb(166, 174, 194)); setPadding(0, 0, 0, dp(22))
        })

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(tile("🎙  Голосовой поиск", "Сказать команду") { startVoice() }, weightParams())
        row1.addView(tile("📺  Приложения", "Открыть установленное приложение") { showApps() }, weightParams())
        row1.addView(tile("📹  Видеозвонки", "Найти совместимые приложения") { showVideoApps() }, weightParams())
        root.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, 0) }
        row2.addView(tile("🔌  Источники", "HDMI и системные входы") {
            toast("Переключение HDMI пока выполняется штатным пультом: системный API не подтверждён.")
        }, weightParams())
        row2.addView(tile("⚙  Настройки", "Состояние и информация") { showInfo() }, weightParams())
        root.addView(row2)

        status = TextView(this).apply {
            text = "Готово к работе  •  Версия 0.1 alpha"
            textSize = 14f; setTextColor(Color.rgb(150, 160, 182)); setPadding(0, dp(22), 0, 0)
        }
        root.addView(status)
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        root.requestFocus()
    }

    private fun tile(title: String, subtitle: String, action: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            setBackgroundColor(panel)
            isFocusable = true; isClickable = true
            foreground = getDrawable(android.R.drawable.list_selector_background)
            setOnClickListener { action() }
        }
        box.addView(TextView(this).apply { text = title; textSize = 20f; setTextColor(Color.WHITE) })
        box.addView(TextView(this).apply { text = subtitle; textSize = 13f; setTextColor(Color.rgb(170, 178, 198)); setPadding(0, dp(8), 0, 0) })
        return box
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, dp(112), 1f).apply { marginEnd = dp(12) }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), permissionRequest); return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажите команду")
        }
        try { startActivityForResult(intent, speechRequest) }
        catch (_: ActivityNotFoundException) { toast("На телевизоре не найден совместимый сервис распознавания речи.") }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val phrase = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            status.text = if (phrase.isBlank()) "Не удалось распознать команду" else "Распознано: «$phrase»"
            handleVoiceCommand(phrase.lowercase(Locale("ru", "RU")))
        }
    }

    private fun handleVoiceCommand(command: String) {
        when {
            command.contains("прилож") || command.contains("програм") -> showApps()
            command.contains("звон") || command.contains("видеосвяз") -> showVideoApps()
            command.contains("настрой") -> showInfo()
            command.contains("youtube") || command.contains("ютуб") -> launchByName("youtube")
            command.contains("назад") -> onBackPressedDispatcher.onBackPressed()
            else -> toast("Команда распознана, но действие ещё не подключено. Добавим обработчики на следующем этапе.")
        }
    }

    private fun showApps() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val labels = apps.take(80).map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        if (labels.isEmpty()) { toast("Список приложений недоступен на этой версии системы."); return }
        android.app.AlertDialog.Builder(this).setTitle("Приложения")
            .setItems(labels) { _, which ->
                val app = apps[which]
                val launch = pm.getLaunchIntentForPackage(app.packageName)
                try { if (launch != null) startActivity(launch) else toast("Нет команды запуска") }
                catch (_: Exception) { toast("Не удалось открыть приложение") }
            }.setNegativeButton("Закрыть", null).show()
    }

    private fun showVideoApps() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA).filter { app ->
            val name = pm.getApplicationLabel(app).toString().lowercase()
            val pkg = app.packageName.lowercase()
            (listOf("meet", "zoom", "telegram", "skype", "whatsapp", "meetime", "видео", "звон").any { name.contains(it) || pkg.contains(it) }) && pm.getLaunchIntentForPackage(app.packageName) != null
        }.sortedBy { pm.getApplicationLabel(it).toString() }
        if (apps.isEmpty()) { toast("Совместимые приложения видеосвязи не обнаружены. Установи приложение и проверь его совместимость с телевизором."); return }
        val labels = apps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        android.app.AlertDialog.Builder(this).setTitle("Видеосвязь")
            .setItems(labels) { _, which -> startActivity(pm.getLaunchIntentForPackage(apps[which].packageName)) }
            .setNegativeButton("Закрыть", null).show()
    }

    private fun launchByName(query: String) {
        val pm = packageManager
        val app = pm.getInstalledApplications(PackageManager.GET_META_DATA).firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(query) || it.packageName.lowercase().contains(query)
        }
        val intent = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (intent != null) startActivity(intent) else toast("Приложение не найдено. Установи совместимую версию и повтори.")
    }

    private fun showInfo() {
        android.app.AlertDialog.Builder(this).setTitle("Vision Next · Alpha")
            .setMessage("Это прототип оболочки. Голосовой ввод запускается вручную. Постоянное прослушивание, запуск оболочки вместо домашнего экрана, управление HDMI и доступ к встроенной камере требуют отдельной проверки на реальном телевизоре.")
            .setPositiveButton("Понятно", null).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
