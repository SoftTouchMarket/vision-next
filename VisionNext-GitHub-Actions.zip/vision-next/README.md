# Vision Next — prototype launcher for Huawei Vision S55

This is an experimental Android launcher prototype, not firmware and not a replacement for HarmonyOS. It does not modify the TV system. Compatibility with Huawei Vision S55 / HarmonyOS 2.0 must be tested on the actual device.

## Free cloud build from an iPhone using GitHub Actions

1. Create a **public** repository on GitHub named `vision-next` (public repositories use standard GitHub-hosted Actions runners free of charge).
2. Upload the contents of this folder to the repository, keeping the `.github/workflows/android.yml` file and the `app` folder at the repository root. On GitHub mobile, use the browser's desktop site if needed. Do not upload the ZIP as one file; upload the extracted project files.
3. Open the repository's **Actions** tab and allow workflows if GitHub asks.
4. Select **Build Vision Next APK** and tap **Run workflow** (or push to `main` to start automatically).
5. When the run finishes with a green check, open that run, find **Artifacts**, and download `vision-next-debug-apk`.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

A public repository makes the source code visible to everyone. Do not upload passwords, tokens, personal data, or private files. No payment method should be needed for standard runners on a public repository. Check GitHub's current Actions billing documentation before changing repository visibility or runner type.

## Notes

- Requires JDK 17 and Gradle 8.7; the workflow installs these in the cloud, so no Gradle wrapper is needed in the uploaded source.
- The app is a debug APK and is unsigned with a release key; it is intended for compatibility testing only.
- Voice input depends on a speech-recognition service being available on the TV. It is not always-listening voice control.
- Video-call support is not implemented directly; the prototype only searches for compatible installed apps. Access to the TV's built-in camera is not guaranteed.
